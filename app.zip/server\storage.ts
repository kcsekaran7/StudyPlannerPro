import { 
  Task, 
  TaskStatus, 
  InsertTask, 
  InsertTaskStatus, 
  TaskWithStatus 
} from "@shared/schema";

// Storage interface
export interface IStorage {
  // Tasks
  getTasks(): Promise<TaskWithStatus[]>;
  getTasksByDate(date: Date): Promise<TaskWithStatus[]>;
  getTask(id: number): Promise<TaskWithStatus | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, updates: Partial<InsertTask>): Promise<TaskWithStatus>;
  deleteTask(id: number): Promise<boolean>;
  
  // Task Status
  getTaskStatus(taskId: number): Promise<TaskStatus | undefined>;
  updateTaskStatus(taskId: number, status: 'completed' | 'partial' | 'not_started' | 'not_needed'): Promise<TaskStatus>;
  createTaskStatus(taskStatus: InsertTaskStatus): Promise<TaskStatus>;
  
  // Sync with external data
  syncExternalTasks(tasks: any[]): Promise<boolean>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private tasks: Map<number, Task>;
  private taskStatuses: Map<number, TaskStatus>;
  private currentTaskId: number;
  private currentStatusId: number;

  constructor() {
    this.tasks = new Map();
    this.taskStatuses = new Map();
    this.currentTaskId = 1;
    this.currentStatusId = 1;
    
    // Add some initial sample tasks for demonstration
    this.addSampleTasks();
  }
  
  // Initialize with sample data
  private addSampleTasks() {
    // Today's tasks
    const today = new Date();
    
    // Math study task
    const task1: Task = {
      id: this.currentTaskId++,
      title: "Linear Algebra Practice Problems",
      description: "Complete exercises 2.1-2.10 from the textbook",
      subject: "Mathematics",
      duration: 60,
      resources: "Textbook Chapter 2, Online lecture notes",
      scheduledDate: today,
      cloudId: "sample-math-1"
    };
    this.tasks.set(task1.id, task1);
    
    // Physics task
    const task2: Task = {
      id: this.currentTaskId++,
      title: "Physics Lab Preparation",
      description: "Review experiment procedures and safety guidelines",
      subject: "Physics",
      duration: 45,
      resources: "Lab manual, safety video",
      scheduledDate: today,
      cloudId: "sample-physics-1"
    };
    this.tasks.set(task2.id, task2);
    
    // Tomorrow's task
    const tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);
    
    const task3: Task = {
      id: this.currentTaskId++,
      title: "CS Algorithm Analysis",
      description: "Study time complexity and Big O notation",
      subject: "Computer Science",
      duration: 90,
      resources: "Online course module 3",
      scheduledDate: tomorrow,
      cloudId: "sample-cs-1"
    };
    this.tasks.set(task3.id, task3);
    
    // Set some initial statuses
    const status1: TaskStatus = {
      id: this.currentStatusId++,
      taskId: task1.id,
      status: "partial",
      updatedAt: new Date()
    };
    this.taskStatuses.set(status1.id, status1);
    
    const status2: TaskStatus = {
      id: this.currentStatusId++,
      taskId: task2.id,
      status: "not_started",
      updatedAt: new Date()
    };
    this.taskStatuses.set(status2.id, status2);
  }

  // Get all tasks with their status
  async getTasks(): Promise<TaskWithStatus[]> {
    return Array.from(this.tasks.values()).map(task => {
      const taskStatus = this.taskStatuses.get(
        Array.from(this.taskStatuses.values()).find(
          status => status.taskId === task.id
        )?.id || 0
      );
      
      return {
        ...task,
        status: taskStatus?.status || 'not_started'
      };
    });
  }

  // Get tasks for a specific date
  async getTasksByDate(date: Date): Promise<TaskWithStatus[]> {
    const tasksForDate = Array.from(this.tasks.values()).filter(task => {
      const taskDate = new Date(task.scheduledDate);
      return (
        taskDate.getFullYear() === date.getFullYear() &&
        taskDate.getMonth() === date.getMonth() &&
        taskDate.getDate() === date.getDate()
      );
    });

    return tasksForDate.map(task => {
      const statusEntry = Array.from(this.taskStatuses.values()).find(
        status => status.taskId === task.id
      );
      
      return {
        ...task,
        status: statusEntry?.status || 'not_started'
      };
    });
  }

  // Get a specific task with its status
  async getTask(id: number): Promise<TaskWithStatus | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;

    const statusEntry = Array.from(this.taskStatuses.values()).find(
      status => status.taskId === id
    );

    return {
      ...task,
      status: statusEntry?.status || 'not_started'
    };
  }

  // Create a new task
  async createTask(task: InsertTask): Promise<Task> {
    const id = this.currentTaskId++;
    const newTask: Task = { ...task, id };
    this.tasks.set(id, newTask);
    return newTask;
  }

  // Get status for a task
  async getTaskStatus(taskId: number): Promise<TaskStatus | undefined> {
    return Array.from(this.taskStatuses.values()).find(
      status => status.taskId === taskId
    );
  }

  // Update task status
  async updateTaskStatus(
    taskId: number, 
    status: 'completed' | 'partial' | 'not_started' | 'not_needed'
  ): Promise<TaskStatus> {
    // Check if task exists
    const task = this.tasks.get(taskId);
    if (!task) {
      throw new Error(`Task with id ${taskId} not found`);
    }

    // Find existing status
    const existingStatusEntry = Array.from(this.taskStatuses.entries()).find(
      ([_, status]) => status.taskId === taskId
    );

    if (existingStatusEntry) {
      const [statusId, existingStatus] = existingStatusEntry;
      const updatedStatus: TaskStatus = {
        ...existingStatus,
        status,
        updatedAt: new Date()
      };
      this.taskStatuses.set(statusId, updatedStatus);
      return updatedStatus;
    } else {
      // Create new status if it doesn't exist
      const newStatusId = this.currentStatusId++;
      const newStatus: TaskStatus = {
        id: newStatusId,
        taskId,
        status,
        updatedAt: new Date()
      };
      this.taskStatuses.set(newStatusId, newStatus);
      return newStatus;
    }
  }

  // Create a new task status
  async createTaskStatus(taskStatus: InsertTaskStatus): Promise<TaskStatus> {
    const id = this.currentStatusId++;
    const newStatus: TaskStatus = {
      ...taskStatus,
      id,
      updatedAt: new Date()
    };
    this.taskStatuses.set(id, newStatus);
    return newStatus;
  }
  
  // Update an existing task
  async updateTask(id: number, updates: Partial<InsertTask>): Promise<TaskWithStatus> {
    // Check if task exists
    const existingTask = this.tasks.get(id);
    if (!existingTask) {
      throw new Error(`Task with id ${id} not found`);
    }
    
    // Merge updates with existing task data
    const updatedTask: Task = {
      ...existingTask,
      ...updates
    };
    
    // Save the updated task
    this.tasks.set(id, updatedTask);
    
    // Get the current status for the task
    const statusEntry = Array.from(this.taskStatuses.values()).find(
      status => status.taskId === id
    );
    
    // Return the task with status
    return {
      ...updatedTask,
      status: statusEntry?.status || 'not_started'
    };
  }
  
  // Delete a task
  async deleteTask(id: number): Promise<boolean> {
    // Check if task exists
    const existingTask = this.tasks.get(id);
    if (!existingTask) {
      throw new Error(`Task with id ${id} not found`);
    }
    
    // Delete the task
    const result = this.tasks.delete(id);
    
    // Find and delete any associated status entries
    for (const [statusId, status] of this.taskStatuses.entries()) {
      if (status.taskId === id) {
        this.taskStatuses.delete(statusId);
      }
    }
    
    return result;
  }

  // Sync tasks from external source
  async syncExternalTasks(externalTasks: any[]): Promise<boolean> {
    try {
      // For each external task, create or update a task in our storage
      for (const externalTask of externalTasks) {
        // Look for existing task with the same cloudId
        const existingTask = Array.from(this.tasks.values()).find(
          task => task.cloudId === externalTask.id
        );

        if (existingTask) {
          // Update existing task
          const updatedTask: Task = {
            ...existingTask,
            title: externalTask.title,
            description: externalTask.description || '',
            subject: externalTask.subject,
            duration: externalTask.duration,
            resources: externalTask.resources || '',
            scheduledDate: new Date(externalTask.scheduledDate)
          };
          this.tasks.set(existingTask.id, updatedTask);
        } else {
          // Create new task
          const newTask: InsertTask = {
            title: externalTask.title,
            description: externalTask.description || '',
            subject: externalTask.subject,
            duration: externalTask.duration,
            resources: externalTask.resources || '',
            scheduledDate: new Date(externalTask.scheduledDate),
            cloudId: externalTask.id
          };
          await this.createTask(newTask);
        }
      }
      return true;
    } catch (error) {
      console.error("Failed to sync external tasks:", error);
      return false;
    }
  }
}

// Export an instance of MemStorage for the application to use
export const storage = new MemStorage();
