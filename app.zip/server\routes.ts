import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { statusUpdateSchema, insertTaskSchema } from "@shared/schema";
import { ZodError } from "zod";
import fetch from "node-fetch";

// Default cloud data URL - would normally be in environment variables
const STUDY_PLAN_URL = process.env.STUDY_PLAN_URL || "https://api.jsonbin.io/v3/b/PLACEHOLDER_ID";

// Sample task data for demonstration purposes
const SAMPLE_DATA = {
  tasks: [
    {
      id: "cloud-math-01",
      title: "Calculus Review Session",
      description: "Review limits, derivatives, and integrals",
      subject: "Mathematics",
      duration: 90,
      resources: "Calculus textbook chapters 1-3, lecture notes",
      scheduledDate: new Date().toISOString(),
    },
    {
      id: "cloud-eng-01",
      title: "English Literature Essay",
      description: "Write comparative analysis essay on assigned readings",
      subject: "English",
      duration: 120,
      resources: "Course readings, library resources",
      scheduledDate: new Date().toISOString(),
    },
    {
      id: "cloud-sci-01",
      title: "Chemistry Lab Preparation",
      description: "Read experiment procedures and complete pre-lab questions",
      subject: "Science",
      duration: 45,
      resources: "Lab manual, online resources",
      scheduledDate: new Date(new Date().setDate(new Date().getDate() + 1)).toISOString(),
    }
  ]
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);
  
  // === API Routes ===
  
  // Get all tasks
  app.get("/api/tasks", async (req, res) => {
    try {
      const tasks = await storage.getTasks();
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });
  
  // Get tasks for a specific date
  app.get("/api/tasks/date/:date", async (req, res) => {
    try {
      const dateStr = req.params.date;
      const date = new Date(dateStr);
      
      if (isNaN(date.getTime())) {
        return res.status(400).json({ message: "Invalid date format. Use YYYY-MM-DD" });
      }
      
      const tasks = await storage.getTasksByDate(date);
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks by date:", error);
      res.status(500).json({ message: "Failed to fetch tasks for date" });
    }
  });
  
  // Get a specific task
  app.get("/api/tasks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }
      
      const task = await storage.getTask(id);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.json(task);
    } catch (error) {
      console.error("Error fetching task:", error);
      res.status(500).json({ message: "Failed to fetch task" });
    }
  });
  
  // Create a new task
  app.post("/api/tasks", async (req, res) => {
    try {
      // Validate the input
      const taskData = req.body;
      
      // Convert scheduledDate if it's received in ISO string format
      if (typeof taskData.scheduledDate === 'string') {
        taskData.scheduledDate = new Date(taskData.scheduledDate);
      }
      
      // Generate a unique cloudId for the task
      taskData.cloudId = `user-${Date.now()}`;
      
      // Validate the data using Zod schema
      const validatedData = insertTaskSchema.parse(taskData);
      
      // Create the task
      const newTask = await storage.createTask(validatedData);
      
      // Create initial status (not_started) for the task
      await storage.createTaskStatus({
        taskId: newTask.id,
        status: 'not_started',
        updatedAt: new Date()
      });

      res.status(201).json({
        success: true,
        task: {
          ...newTask,
          status: 'not_started' // Include the status in the response
        }
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid task data", 
          errors: error.errors 
        });
      }
      
      console.error("Error creating task:", error);
      res.status(500).json({ message: "Failed to create task" });
    }
  });
  
  // Update an existing task
  app.patch("/api/tasks/:id", async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      
      if (isNaN(taskId)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }
      
      // Check if the task exists
      const existingTask = await storage.getTask(taskId);
      if (!existingTask) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      // Prepare the update data
      const updateData = req.body;
      
      // Convert scheduledDate if it's received in ISO string format
      if (typeof updateData.scheduledDate === 'string') {
        updateData.scheduledDate = new Date(updateData.scheduledDate);
      }
      
      // Update the task
      const updatedTask = await storage.updateTask(taskId, updateData);
      
      res.json({
        success: true,
        task: updatedTask
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid task data", 
          errors: error.errors 
        });
      }
      
      console.error("Error updating task:", error);
      res.status(500).json({ message: "Failed to update task" });
    }
  });
  
  // Delete a task
  app.delete("/api/tasks/:id", async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      
      if (isNaN(taskId)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }
      
      // Check if the task exists
      const existingTask = await storage.getTask(taskId);
      if (!existingTask) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      // Delete the task
      await storage.deleteTask(taskId);
      
      res.json({
        success: true,
        message: "Task deleted successfully"
      });
    } catch (error) {
      console.error("Error deleting task:", error);
      res.status(500).json({ message: "Failed to delete task" });
    }
  });
  
  // Update task status
  app.post("/api/tasks/status", async (req, res) => {
    try {
      const data = statusUpdateSchema.parse(req.body);
      
      const task = await storage.getTask(data.taskId);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      const updatedStatus = await storage.updateTaskStatus(data.taskId, data.status);
      res.json({ 
        success: true, 
        status: updatedStatus
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid request data", 
          errors: error.errors 
        });
      }
      
      console.error("Error updating task status:", error);
      res.status(500).json({ message: "Failed to update task status" });
    }
  });
  
  // Sync tasks from external source
  app.post("/api/sync", async (req, res) => {
    try {
      // Check if we're using sample data mode
      const useSampleData = req.body.useSampleData === true || req.body.url === 'sample';
      
      let tasks;
      
      if (useSampleData) {
        // Use our predefined sample data
        console.log("Using sample data for sync");
        tasks = SAMPLE_DATA.tasks;
      } else {
        // Get the custom URL from request body or use default
        const dataUrl = req.body.url || STUDY_PLAN_URL;
        
        try {
          // Fetch data from the external source
          const response = await fetch(dataUrl);
          
          if (!response.ok) {
            // If external fetch fails, use sample data as fallback
            console.log(`External data fetch failed (${response.status}), using sample data instead`);
            tasks = SAMPLE_DATA.tasks;
          } else {
            const data = await response.json();
            
            // Process the data - handle different API response formats
            if (data.record) {
              // If using JSONBin.io format
              tasks = data.record.tasks || data.record;
            } else {
              // Assume direct array or object with tasks property
              tasks = Array.isArray(data) ? data : data.tasks;
            }
            
            if (!tasks || !Array.isArray(tasks)) {
              console.log("Invalid data format from source, using sample data instead");
              tasks = SAMPLE_DATA.tasks;
            }
          }
        } catch (fetchError) {
          // If fetch fails completely, use sample data
          console.log("Failed to fetch from external source, using sample data instead:", fetchError);
          tasks = SAMPLE_DATA.tasks;
        }
      }
      
      // Sync tasks to our storage
      const success = await storage.syncExternalTasks(tasks);
      
      if (success) {
        res.json({ 
          success: true, 
          message: "Successfully synced tasks",
          count: tasks.length,
          usedSampleData: useSampleData || tasks === SAMPLE_DATA.tasks
        });
      } else {
        res.status(500).json({ 
          message: "Failed to sync tasks" 
        });
      }
    } catch (error) {
      console.error("Error syncing tasks:", error);
      res.status(500).json({ 
        message: "Failed to sync tasks from external source",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  return httpServer;
}
